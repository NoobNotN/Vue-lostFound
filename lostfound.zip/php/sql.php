<?php
require_once 'connectDatabase.php';
$Tool = new funTool();
$conn = $Tool->connectDatabase();

$sql = "CREATE TABLE TableToken
(
    id int not null primary key,
    foreign key (id) references users(id),
    lost_name LINESTRING ,
    lost_time DATETIME
    
);";

if ($conn->query($sql) === true){
    echo "success";
} else {
    echo "error".$conn->error;
}

$conn->close();
