module.exports = {
    // assetsDir:'./',
    publicPath : './',
    // devServer:{
    //     // proxy:{
    //     //     '/php':{
    //     //         target: 'http://localhost/lostFound/lostFound/php',
    //     //         ws: true,
    //     //         changeOrigin: true,
    //     //         pathRewrite:{
    //     //             '^/php':''
    //     //         }
    //     //     }
    //     // }
    // }
};
