<template>
    <div>
        懒得写了<br>
        backer:{{userID}}
    </div>
</template>

<script>
    const axios = require('axios');
    export default {
        name: "userPage",
        data(){return{
            userID :'index',
        }},
        methods:{
            getUserList: function () {
                axios.post('http://localhost:8080/lostfound/php/UserList.php', {
                    userID: this.userID,
                })
                    .then((response)=>{
                        let data = response.data;
                        console.log(data);
                    })
                    .catch((error)=>{
                        console.log(error);
                    })
            }
        },
        mounted() {
            this.getUserList();
        },
    }
</script>

<style scoped>

</style>
