<?php
header('content-type:text/html;charset=utf-8');

$val = 77;

if(is_numeric($val)) {
    if( $val>=0&&$val<=100) {
        if($val>=90) {
            echo '优秀';
        } elseif($val>=80) {
            echo '良上';
        } elseif($val>=70) {
            echo '良下';
        } elseif($val>=60) {
            echo '及格';
        } else {
            echo '不及格';
        }
    } else {
        echo 'false -> 0 < data < 100!';
    }
} else {
    echo 'false -> number';
}


/*  
 * 多分支语句或switch
 * [90,100] 输出优秀
 * [80,90)  输出良上
 * [70,80)  输出良下
 * [60,70)  输出及格
 * [0,60)   输出不及格
 * 其他：
 *    判断输出的是合法数字或数字字符串
 *    判断输出的范围是 0-100范围
 */
?>
