<?php
$getIn = file_get_contents('php://input');
$getIn = json_decode($getIn,true);
$userID = $getIn['userID'];
echo 'userID: '.$userID;
