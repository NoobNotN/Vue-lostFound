<?php
header('content-type:text/html;charset=utf-8');

function b($data){
    echo "'a',$data,'b'"."<br>";
}
b('null');
b('false');
b('true');
b(false);
b(true);

function a($data){
    echo boolval($data).'<br>';
}
a('false');
a('true');
a('0000001');
a('true');
a('0000001');
a(2.15);
a(2e-3);
/*输出结果
*  1. 'a','null','b'
*  2. 'a','false','b'
*  3. 'a','true','b'
*  4. 'a',false,'b'
*  5. 'a',true,'b'
*
*  6. 判断转换成布尔值： 'false'
*  7. 判断转换成布尔值： 'true'
*  8. 判断转换成布尔值： 'null'
*  9. 判断转换成布尔值： '0000001'
*  10.判断转换成布尔值： 000001
*  11.判断转换成布尔值： 2.15
*  13.判断转换成布尔值： 2e-3
*
*/
?>
