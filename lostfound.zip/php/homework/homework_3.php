<?php
header('content-type:text/html;charset=utf-8');

$str='40/(13+12)';
echo eval("return $str;")."<br>";

for ($i=100; $i < 1000; $i++) { 
    $a = $i % 10;
    $b = (int)($i / 100);
    $c = (int)($i / 10 % 10);
    if ((($a*$a*$a)+($b*$b*$b)+($c*$c*$c)) == $i) {
        echo $i.",";
    }
}

/*1. 实现一个简单计算器
 *2.水仙花（3位数）
 *
 *   153 = 1^3 + 5^3 +3^3 =153
 *   百位立方 + 十位立方+个位立方 =自身 
 *  求  100-999中的水仙花   
 */
?>
